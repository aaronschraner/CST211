/********************************************************************************
 * Author:            Aaron Schraner
 * Date Created:      November 15, 2015
 * Last Modified:     November 15, 2015
 * Assignment number: 7 Graphs
 * Filename:          Vertex_impl.h
 * 
 ********************************************************************************/
#ifndef VERTEX_IMPL_H
#define VERTEX_IMPL_H

//here for future use

#endif

